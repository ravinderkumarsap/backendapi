package com.example.demo.demo.sercvice;

import com.example.demo.demo.model.TransferRequest;
import jakarta.ws.rs.core.Response;

public interface TransferService {
    Response acceptTransfer(TransferRequest transferRequest);

    Response getTransfer(Long id);

    Response getTransferContents(Long id);
}

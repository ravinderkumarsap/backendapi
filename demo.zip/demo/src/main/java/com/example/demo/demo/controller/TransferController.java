package com.example.demo.demo.controller;

import com.example.demo.demo.entity.Transfer;
import com.example.demo.demo.model.TransferRequest;
import com.example.demo.demo.sercvice.TransferService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("/api/v1/transfer")
@ApplicationScoped
public class TransferController {
    @Inject
    private TransferService transfersAPIService;

    @POST
    @Path("/")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response acceptTransfer(TransferRequest transferRequest) {
        return this.transfersAPIService.acceptTransfer(transferRequest);
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTransfer(@PathParam("id") Long id) {
        return this.transfersAPIService.getTransfer(id);
    }

    @GET
    @Path("/{id}/contents")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getTransferContents(@PathParam("id") Long id) {
        return this.transfersAPIService.getTransferContents(id);
    }

}

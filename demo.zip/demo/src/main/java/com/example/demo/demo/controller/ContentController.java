package com.example.demo.demo.controller;

import com.example.demo.demo.sercvice.ContentService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.Context;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;

@Path("/api/v1/content")
public class ContentController {

    @Inject
    private ContentService contentService;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll() {
        return this.contentService.getAll();
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getById(@PathParam("id") Long id) {
        return contentService.getById(id);
    }

    @POST
    @Path("/")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response postContent(String requestBody, @Context UriInfo uriInfo) {
        return this.contentService.postContent(requestBody, uriInfo);
    }

}

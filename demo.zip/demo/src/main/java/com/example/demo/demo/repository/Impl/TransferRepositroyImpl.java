package com.example.demo.demo.repository.Impl;

import com.example.demo.demo.entity.Content;
import com.example.demo.demo.entity.Transfer;
import com.example.demo.demo.model.ContentsModel;
import com.example.demo.demo.model.TransfersModel;
import com.example.demo.demo.repository.TransferRespositroy;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class TransferRepositroyImpl implements TransferRespositroy {

    private static final Logger logger = Logger.getLogger(TransferRepositroyImpl.class.getName());

    @Override
    public Long createTransferWithID(String asset, String contents, String id) {

        try {
            Transfer transfer = new Transfer();
            transfer.setTransferid(id);
            transfer.setAsset(asset);
            transfer.setContents(contents);
            getEntityManager().getTransaction().begin();
            getEntityManager().persist(transfer);
            getEntityManager().getTransaction().commit();
            if(transfer.getId() != null){
                return  transfer.getId();
            }else {
                return -1L;
            }
        }catch (Exception e){
            e.printStackTrace();
            logger.info(e.getMessage());
        }finally {
            getEntityManager().close();
        }

        return null;
    }

    @Override
    public TransfersModel getTransferById(Long id) {
        Transfer transfer =  getEntityManager().find(Transfer.class, id);
        TransfersModel transfersModel = new TransfersModel(transfer.getId(),transfer.getAsset(),transfer.getContents(),transfer.getCreatedDate(), transfer.getUpdatedDate());
        return transfersModel;
    }

    @Override
    public void updateTransfer(Long id, String newAsset) {
        try {
            Transfer transfer =  getEntityManager().find(Transfer.class, id);
            transfer.setAsset(newAsset);
            getEntityManager().getTransaction().begin();
            getEntityManager().remove(transfer);
            getEntityManager().getTransaction().commit();
        }catch (Exception e){
            logger.info(e.getMessage());
        }finally {
            getEntityManager().close();
        }
    }

    @Override
    public void deleteTransfer(Long id) {
        try {
            Transfer transfer =  getEntityManager().find(Transfer.class, id);
            getEntityManager().getTransaction().begin();
            getEntityManager().remove(transfer);
            getEntityManager().getTransaction().commit();
        }catch (Exception e){
            logger.info(e.getMessage());
        }finally {
            getEntityManager().close();
        }
    }

    @Override
    public List<TransfersModel> getAllTransfers() {
        List<TransfersModel> response = new ArrayList<TransfersModel>();
        try {
            Query query = getEntityManager().createQuery("select e from Content e", Content.class);
            List<Transfer> transferList =  query.getResultList();
            transferList.forEach(data->{
                TransfersModel transfersModel = new TransfersModel(data.getId(),data.getAsset(), data.getContents(),data.getCreatedDate(), data.getCreatedDate());
                response.add(transfersModel);
            });
        }catch (Exception e){
            logger.info(e.getMessage());
        }finally {
            getEntityManager().close();
        }
        return response.isEmpty() ? null : response;
    }

    public EntityManager getEntityManager(){
        EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("default");
        return entityManagerFactory.createEntityManager();
    }
}

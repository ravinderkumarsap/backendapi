package com.example.demo.demo.sercvice.Impl;

import com.example.demo.demo.entity.Content;
import com.example.demo.demo.model.ContentsModel;
import com.example.demo.demo.repository.ContentServiceRepository;
import com.example.demo.demo.sercvice.ContentService;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.persistence.*;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.UriInfo;
import java.util.logging.Logger;


@ApplicationScoped
public class ContentServiceImpl implements ContentService {

    private static final Logger logger = Logger.getLogger(ContentServiceImpl.class.getName());

    @Inject
    private ContentServiceRepository contentServiceRepository;

    @Override
    public Response getAll() {
        try {
            EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("default");
            EntityManager entityManager=entityManagerFactory.createEntityManager();
            Query query = entityManager.createQuery("select e from Content e", Content.class);
            if (query != null) {
                return Response.ok(query.getResultList()).build();
            } else {
                return Response.status(Response.Status.NOT_FOUND).entity("Asset not found").build();
            }
        }catch (Exception e){
            logger.info(e.getMessage());
            return Response.serverError().entity("Internal server error").build();
        }
    }

    @Override
    public Response getById(Long id) {
       try {
          ContentsModel content =  this.contentServiceRepository.getAssetById(id);
           if (content != null) {
               return Response.ok(content).build();
           } else {
               return Response.status(Response.Status.NOT_FOUND).entity("Asset not found").build();
           }
       }catch (Exception e){
           logger.info(e.getMessage());
           return Response.serverError().entity("Internal server error").build();
       }
    }

    @Override
    public Response postContent(String requestBody, UriInfo uriInfo) {
        try {
           Long id = contentServiceRepository.createAsset(requestBody);
            if(id != null){
                logger.info(uriInfo.getAbsolutePath()+"");
                return Response.ok(uriInfo.getAbsolutePath() + "/" + id).build();
            }else{
                return Response.status(Response.Status.NOT_FOUND).entity("Asset Not Created").build();
            }
        }catch (Exception e){
            logger.info(e.getMessage());
            return Response.serverError().entity("Internal server error").build();
        }
    }
}

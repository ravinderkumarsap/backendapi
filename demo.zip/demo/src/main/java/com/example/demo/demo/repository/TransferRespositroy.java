package com.example.demo.demo.repository;

import com.example.demo.demo.model.TransfersModel;

import java.util.List;

public interface TransferRespositroy {

    Long createTransferWithID(String asset, String contents, String id);

    TransfersModel getTransferById(Long id);

    void updateTransfer(Long id, String newAsset);

    void deleteTransfer(Long id);

    List<TransfersModel> getAllTransfers();

}

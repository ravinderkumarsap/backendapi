package com.example.demo.demo.model;

public class PropertiesModel {

}

package com.example.demo.demo.repository.Impl;

import com.example.demo.demo.entity.Content;
import com.example.demo.demo.model.ContentsModel;
import com.example.demo.demo.repository.ContentServiceRepository;
import com.google.gson.Gson;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.Query;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

@ApplicationScoped
public class ContentRepositoryImpl implements ContentServiceRepository {

    private static final Logger logger = Logger.getLogger(ContentRepositoryImpl.class.getName());

    @Override
    public Long createAsset(String assetName) {
        try {
            Content content =  saveContent(assetName);
            if(content.getId() != null){
                logger.info(content.toString());
                return content.getId();
            }else{
                return -1L;
            }
        }catch (Exception e){
            e.printStackTrace();
            logger.info(e.getMessage());
            return -1L;
        }finally {
            getEntityManager().close();
        }
    }

    public Content saveContent(String assetName) {
        Content content = new Content();
       try {
           Gson gson = new Gson();
           String contentRequestJson = gson.toJson(assetName);
           content.setAsset(contentRequestJson);
           getEntityManager().getTransaction().begin();
           getEntityManager().persist(content);
           getEntityManager().getTransaction().commit();
       }catch (Exception e){
           e.printStackTrace();
           logger.info(e.getMessage());
       }finally {
           getEntityManager().close();
       }
        return content;
    }

    @Override
    public ContentsModel getAssetById(Long id) {
        Content content =  getEntityManager().find(Content.class, id);
        ContentsModel response = new ContentsModel(content.getId(),content.getAsset(),content.getCreatedDate(), content.getUpdatedDate());
        return response;
    }

    @Override
    public void updateAsset(Long id, String newAssetName) {
      try {
          Content content =  getEntityManager().find(Content.class, id);
          content.setAsset(newAssetName);
          getEntityManager().getTransaction().begin();
          getEntityManager().persist(content);
          getEntityManager().getTransaction().commit();
      }catch (Exception e){
          logger.info(e.getMessage());
      }finally {
          getEntityManager().close();
      }
    }

    @Override
    public void deleteAsset(Long id) {

        try {
            Content content =  getEntityManager().find(Content.class, id);
            getEntityManager().getTransaction().begin();
            getEntityManager().remove(content);
            getEntityManager().getTransaction().begin();

        }catch (Exception e){
            logger.info(e.getMessage());
        }finally {
            getEntityManager().close();
        }

    }

    @Override
    public List<ContentsModel> getAllAssets() {
        List<ContentsModel> response = new ArrayList<ContentsModel>();
        try {
            Query query = getEntityManager().createQuery("select e from Content e", Content.class);
            List<Content> contentList =  query.getResultList();
            contentList.forEach(data->{
                ContentsModel contentsModel = new ContentsModel(data.getId(),data.getAsset(),data.getCreatedDate(), data.getCreatedDate());
                response.add(contentsModel);
            });
        }catch (Exception e){
            logger.info(e.getMessage());
        }finally {
            getEntityManager().close();
        }
        return response.isEmpty() ? null : response;
    }

    public EntityManager getEntityManager(){
        EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("default");
        return entityManagerFactory.createEntityManager();
    }
}

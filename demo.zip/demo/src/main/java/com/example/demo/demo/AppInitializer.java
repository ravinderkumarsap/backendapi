package com.example.demo.demo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

@WebListener
public class AppInitializer implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		EntityManagerFactory entityManagerFactory= Persistence.createEntityManagerFactory("default");
		//EntityManager entityManager=entityManagerFactory.createEntityManager();
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {

	}
}
